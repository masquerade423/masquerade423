import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Seedance AI Studio",
  description: "Studio pribadi untuk generasi video AI.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
