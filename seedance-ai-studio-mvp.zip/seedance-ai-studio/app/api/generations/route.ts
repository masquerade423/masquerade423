import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: { prompt?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body request harus berupa JSON." }, { status: 400 });
  }

  if (typeof body.prompt !== "string" || !body.prompt.trim()) {
    return NextResponse.json({ error: "Prompt wajib diisi." }, { status: 400 });
  }

  // TODO: Integrasikan API BytePlus ModelArk setelah endpoint, model ID,
  // dan skema request resmi diverifikasi dari dokumentasi akun Anda.
  // Jangan pernah memindahkan BYTEPLUS_API_KEY ke kode client.
  const configured = Boolean(
    process.env.BYTEPLUS_API_KEY &&
    process.env.BYTEPLUS_BASE_URL &&
    process.env.BYTEPLUS_MODEL
  );

  if (!configured) {
    return NextResponse.json({
      status: "not_configured",
      message: "Server berjalan, tetapi kredensial dan konfigurasi BytePlus belum diatur.",
      prompt: body.prompt.trim(),
    }, { status: 200 });
  }

  return NextResponse.json({
    error: "Konfigurasi tersedia, tetapi adapter API belum diimplementasikan. Verifikasi skema resmi BytePlus sebelum mengirim request.",
  }, { status: 501 });
}
