"use client";

import { useState } from "react";

type Status = "idle" | "submitting" | "error";

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("Isi prompt untuk menyiapkan permintaan generasi video.");
  const [result, setResult] = useState<unknown>(null);

  async function submitGeneration(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!prompt.trim()) {
      setMessage("Prompt belum diisi.");
      return;
    }
    setStatus("submitting");
    setResult(null);
    setMessage("Mengirim permintaan...");
    try {
      const response = await fetch("/api/generations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: prompt.trim() }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Permintaan gagal.");
      setResult(data);
      setMessage("Permintaan diterima oleh server aplikasi.");
      setStatus("idle");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Terjadi kesalahan.");
      setStatus("error");
    }
  }

  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="#"><span className="brand-mark">S</span><span>SEEDANCE <b>AI STUDIO</b></span></a>
        <span className="private-label">PERSONAL WORKSPACE</span>
      </header>
      <section className="hero">
        <div className="eyebrow">AI VIDEO WORKFLOW</div>
        <h1>Ubah ide menjadi<br /><em>video bergerak.</em></h1>
        <p className="intro">Ruang kerja pribadi untuk menyiapkan dan mengelola generasi video AI.</p>
      </section>
      <section className="workspace">
        <form className="prompt-panel" onSubmit={submitGeneration}>
          <div className="panel-heading"><div><span className="step">01</span><h2>Deskripsikan video Anda</h2></div><span className="muted">TEXT TO VIDEO</span></div>
          <label htmlFor="prompt">PROMPT</label>
          <textarea id="prompt" value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Contoh: A cinematic aerial shot of a futuristic Jakarta at golden hour, sleek flying vehicles..." rows={7} />
          <div className="form-footer"><span className="hint">Jelaskan subjek, gerakan kamera, suasana, dan gaya visual.</span><button disabled={status === "submitting"} type="submit">{status === "submitting" ? "Mengirim..." : "Siapkan generasi"} <span>↗</span></button></div>
        </form>
        <aside className="output-panel">
          <div className="panel-heading"><div><span className="step">02</span><h2>Status proses</h2></div><span className="status-dot">● READY</span></div>
          <div className="preview"><div className="preview-grid"></div><div className="play-icon">▶</div><span>VIDEO PREVIEW</span></div>
          <p className="status-message">{message}</p>
          {result && <pre className="result">{JSON.stringify(result, null, 2)}</pre>}
        </aside>
      </section>
      <section className="notice"><span>i</span><p><b>Integrasi API belum diaktifkan.</b> Antarmuka ini sudah disiapkan. Endpoint server masih berupa placeholder sampai model ID, endpoint, dan format request resmi BytePlus dikonfirmasi. API key tidak pernah dikirim ke browser.</p></section>
      <footer><span>SEEDANCE AI STUDIO</span><span>PRIVATE BUILD · 0.1.0</span></footer>
    </main>
  );
}
