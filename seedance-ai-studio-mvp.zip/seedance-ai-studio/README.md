# Seedance AI Studio

A personal Next.js starter for a Seedance video-generation workflow.

## Requirements
- Node.js 20 or newer
- npm
- BytePlus ModelArk credentials and current API documentation (for live generation)

## Run locally
```bash
npm install
cp .env.example .env.local
npm run dev
```
Open http://localhost:3000.

## BytePlus setup
Fill `.env.local` only after confirming the correct API base URL, model identifier, authentication method, and request/response schema in your BytePlus account documentation:

```env
BYTEPLUS_API_KEY=your_server_side_key
BYTEPLUS_BASE_URL=
BYTEPLUS_MODEL=
```

The API route is intentionally a safe placeholder. It validates the prompt but does not send a generation request yet. This avoids guessing an API schema or model identifier. Implement the adapter in `app/api/generations/route.ts` after verifying the current official API docs.

**Security:** never prefix the API key with `NEXT_PUBLIC_`; never put it in client-side code or commit `.env.local`.

## GitHub
Create a new branch (recommended: `feat/seedance-ai-studio-mvp`) and upload the contents of this project folder. Existing repository files are not included or overwritten.
